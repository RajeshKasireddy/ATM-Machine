package com.example.atm;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ATMGUI {
    private ATM atm;
    private JTextField usernameField;
    private JTextField amountField;
    private JTextArea outputArea;

    public ATMGUI(ATM atm) {
        this.atm = atm;
        createAndShowGUI();
    }

    private void createAndShowGUI() {
        JFrame frame = new JFrame("ATM Machine");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        frame.add(panel, BorderLayout.CENTER);
        placeComponents(panel);

        frame.setVisible(true);
    }

    private void placeComponents(JPanel panel) {
        panel.setLayout(null);

        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(10, 20, 80, 25);
        panel.add(userLabel);

        usernameField = new JTextField(20);
        usernameField.setBounds(100, 20, 165, 25);
        panel.add(usernameField);

        JLabel amountLabel = new JLabel("Amount:");
        amountLabel.setBounds(10, 50, 80, 25);
        panel.add(amountLabel);

        amountField = new JTextField(20);
        amountField.setBounds(100, 50, 165, 25);
        panel.add(amountField);

        JButton depositButton = new JButton("Deposit");
        depositButton.setBounds(10, 80, 80, 25);
        panel.add(depositButton);

        JButton withdrawButton = new JButton("Withdraw");
        withdrawButton.setBounds(100, 80, 100, 25);
        panel.add(withdrawButton);

        JButton checkBalanceButton = new JButton("Check Balance");
        checkBalanceButton.setBounds(210, 80, 150, 25);
        panel.add(checkBalanceButton);

        outputArea = new JTextArea();
        outputArea.setBounds(10, 110, 360, 140);
        outputArea.setEditable(false);
        panel.add(outputArea);

        depositButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                performTransaction("deposit");
            }
        });

        withdrawButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                performTransaction("withdraw");
            }
        });

        checkBalanceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                performTransaction("check");
            }
        });
    }

    private void performTransaction(String type) {
        String username = usernameField.getText();
        double amount = 0;
        if (type.equals("deposit") || type.equals("withdraw")) {
            try {
                amount = Double.parseDouble(amountField.getText());
            } catch (NumberFormatException e) {
                outputArea.setText("Invalid amount");
                return;
            }
        }

        User user = new User(username);
        switch (type) {
            case "deposit":
                atm.deposit(user, amount);
                outputArea.setText("Deposited: " + amount);
                break;
            case "withdraw":
                atm.withdraw(user, amount);
                outputArea.setText("Withdrawn: " + amount);
                break;
            case "check":
                atm.checkBalance(user);
                break;
        }
    }
}
