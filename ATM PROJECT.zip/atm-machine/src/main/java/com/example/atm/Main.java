package com.example.atm;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        Bank bank = new Bank();
        User user = new User("john_doe");
        Account account = new Account(user, 1000.0);
        bank.addAccount(account);

        ATM atm = new ATM(bank);
        SwingUtilities.invokeLater(() -> new ATMGUI(atm));
    }
}