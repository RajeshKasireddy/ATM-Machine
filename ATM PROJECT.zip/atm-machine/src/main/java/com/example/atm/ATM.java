package com.example.atm;

public class ATM {
 
    private Bank bank;

    public ATM(Bank bank) {
        this.bank = bank;
    }

    public void deposit(User user, double amount) {
        Account account = bank.getAccount(user);
        if (account != null) {
            account.deposit(amount);
            System.out.println("Deposit successful");
        } else {
            System.out.println("Account not found");
        }
    }

    public void withdraw(User user, double amount) {
        Account account = bank.getAccount(user);
        if (account != null) {
            boolean success = account.withdraw(amount);
            if (success) {
                System.out.println("Withdrawal successful");
            } else {
                System.out.println("Insufficient funds");
            }
        } else {
            System.out.println("Account not found");
        }
    }

    public void checkBalance(User user) {
        Account account = bank.getAccount(user);
        if (account != null) {
            System.out.println("Current balance: " + account.getBalance());
        } else {
            System.out.println("Account not found");
        }
    }
}


