package com.example.atm;

import java.util.HashMap;
import java.util.Map;

public class Bank {
    private Map<String, Account> accounts = new HashMap<>();

    public void addAccount(Account account) {
        accounts.put(account.getUser().getUsername(), account);
    }

    public Account getAccount(User user) {
        return accounts.get(user.getUsername());
    }
}
